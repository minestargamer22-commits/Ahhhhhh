package com.bloodystar.swordanim.mixin;

import com.bloodystar.swordanim.BloodySwordAnimations;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
    private MatrixStack bsa$applyAnimation(MatrixStack matrices) {
        BloodySwordAnimations.PLAYER.apply(matrices);
        return matrices;
    }
}
