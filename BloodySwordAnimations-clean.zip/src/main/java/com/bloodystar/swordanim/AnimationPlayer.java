package com.bloodystar.swordanim;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;

public final class AnimationPlayer {
    public enum Style {
        SWORD_FLIP("Sword Flip", 26),
        HEAVY_ATTACK("Heavy Attack", 32),
        SWORD_DANCE("Sword Dance", 48),
        PHANTOM_SLASH("Phantom Slash", 22),
        EXECUTION("Execution Style", 42);

        public final String title;
        public final int duration;
        Style(String title, int duration) { this.title = title; this.duration = duration; }
    }

    private Style selected = Style.SWORD_FLIP;
    private boolean playing;
    private long startNanos;

    public void select(Style style) { selected = style; }
    public Style selected() { return selected; }
    public boolean playing() { return playing; }

    private float durationSeconds() { return selected.duration * 0.05f; }

    public float progress() {
        if (!playing) return 0f;
        float elapsed = (System.nanoTime() - startNanos) / 1_000_000_000f;
        return Math.min(1f, elapsed / durationSeconds());
    }

    public void playSelected() {
        if (!playing) {
            startNanos = System.nanoTime();
            playing = true;
        }
    }

    public void tick() {
        if (playing && progress() >= 1f) playing = false;
    }

    /** Applies the selected animation to the first-person item matrix. */
    public void apply(MatrixStack m) {
        if (!playing) return;
        float t = progress();
        float s = (float) Math.sin(t * Math.PI);

        // Rotate around roughly where the hand sits on screen.
        m.translate(0.56f, -0.52f, -0.72f);
        switch (selected) {
            case SWORD_FLIP -> {
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-360f * t));
                m.translate(0f, 0.15f * s, 0f);
            }
            case HEAVY_ATTACK -> {
                m.translate(0f, 0.25f * s, 0.1f * s);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-105f * s));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(20f * s));
            }
            case SWORD_DANCE -> {
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(720f * t));
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.sin(t * Math.PI * 4) * 35f));
                m.translate(0f, 0.1f * s, 0f);
            }
            case PHANTOM_SLASH -> {
                m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-150f * s));
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-60f * s));
                m.translate(-0.15f * s, 0f, 0f);
            }
            case EXECUTION -> {
                float raise = t < 0.5f ? (t / 0.5f) : 1f;
                float slam = t < 0.5f ? 0f : (t - 0.5f) / 0.5f;
                m.translate(0f, 0.3f * raise - 0.45f * slam, 0f);
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-70f * raise + 130f * slam));
            }
        }
        m.translate(-0.56f, 0.52f, 0.72f);
    }
}
