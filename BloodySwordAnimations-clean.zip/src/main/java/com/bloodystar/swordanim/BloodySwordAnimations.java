package com.bloodystar.swordanim;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.registry.tag.ItemTags;
import org.lwjgl.glfw.GLFW;

public final class BloodySwordAnimations implements ClientModInitializer {
    public static final String MOD_ID = "bloody_sword_animations";
    private static KeyBinding menuKey;
    private static boolean attackWasDown;
    public static AnimationPlayer PLAYER = new AnimationPlayer();

    @Override
    public void onInitializeClient() {
        ModConfig.load();
        try {
            PLAYER.select(AnimationPlayer.Style.valueOf(ModConfig.get().selectedStyle));
        } catch (IllegalArgumentException ignored) { }

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bloody_sword_animations.menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.player != null) client.setScreen(new AnimationMenuScreen());
            }
            PLAYER.tick();

            // isPressed + edge detection: wasPressed() is already consumed by the game's own attack handling.
            boolean down = client.options.attackKey.isPressed();
            if (down && !attackWasDown
                    && client.currentScreen == null
                    && holdingSword(client)
                    && ModConfig.get().animationsEnabled
                    && ModConfig.get().playOnLeftClick) {
                PLAYER.playSelected();
            }
            attackWasDown = down;
        });
    }

    public static boolean holdingSword(MinecraftClient client) {
        return client.player != null && client.player.getMainHandStack().isIn(ItemTags.SWORDS);
    }
}
