# Bloody Sword Animations (Fabric)

Target: Minecraft Java 1.21.11, Fabric Loader, Java 21.

## Build
Push this repository to GitHub. GitHub Actions runs `gradle build`; download the
`BloodySwordAnimations` artifact from the workflow run.

## Config profiles
The mod stores settings in `config/bloody-sword-animations.json`.
The O menu offers Default, PvP, and Showcase presets. The selected style is saved.

## Current implementation status
This is a starter project: it registers the O menu, five selectable styles,
left-click triggering, and saved config presets. It calculates animation motion
profiles, but it does **not yet connect those profiles to Minecraft's first-person
item renderer**. The visible sword choreography (floating/360 spin/character-face
reveal, body rotation, slash trails) still requires a renderer mixin and model
transform pipeline.

All six vanilla sword materials are supported through `SwordItem`; no new item is added.
See MODRINTH_PROFILE.md for the prepared Modrinth project profile and honest release notes.
