# Modrinth project profile — Bloody Sword Animations

**Project title:** Bloody Sword Animations  
**Suggested slug:** `bloody-sword-animations`  
**Project type:** Mod  
**Primary loader:** Fabric  
**Minecraft version:** 1.21.11  
**Client-side:** Yes  
**Suggested categories:** Utility, Decoration (choose final categories in Modrinth's upload form)

## Short description
A client-side Fabric mod concept for stylish first-person sword flourishes, with an in-game style menu bound to O and saved configuration profiles.

## Full description
Bloody Sword Animations aims to add five selectable first-person sword flourishes to vanilla Minecraft swords. Open the style menu with **O**, choose a style, and trigger it with left-click. It does not add new sword items and is designed to leave vanilla damage and combat mechanics unchanged.

Included configuration profiles:
- **Default** — Sword Flip, plays on left-click.
- **PvP** — Phantom Slash, plays on left-click.
- **Showcase** — Sword Dance, left-click playback disabled.

## Compatibility
- Minecraft Java Edition 1.21.11
- Fabric Loader
- Java 21

## Important release status
This repository is currently a starter implementation. The menu, style selection, config persistence, and animation timing state are present, but the full visible 3D sword choreography still requires the first-person renderer integration. Do not publish it as a finished animation mod until that renderer work is implemented and tested.

## Before publishing
1. Add a project icon and screenshots captured from the working mod.
2. Confirm the license and add a LICENSE file.
3. Build and test the JAR on Minecraft 1.21.11 + Fabric.
4. Complete the renderer integration and verify all five animations.
5. Upload the JAR on Modrinth and select Fabric + Minecraft 1.21.11.
