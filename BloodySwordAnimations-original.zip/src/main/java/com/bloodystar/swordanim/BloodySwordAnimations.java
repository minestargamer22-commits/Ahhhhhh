package com.bloodystar.swordanim;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.SwordItem;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class BloodySwordAnimations implements ClientModInitializer {
    public static final String MOD_ID = "bloody_sword_animations";
    private static KeyBinding menuKey;
    private static AnimationMenuScreen menu;
    public static AnimationPlayer PLAYER = new AnimationPlayer();

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bloody_sword_animations.menu",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.player != null) client.setScreen(new AnimationMenuScreen());
            }
            PLAYER.tick();
            if (client.player != null && client.options.attackKey.wasPressed()) {
                if (client.player.getMainHandStack().getItem() instanceof SwordItem) {
                    PLAYER.playSelected();
                }
            }
        });
    }

    public static boolean holdingSword(MinecraftClient client) {
        return client.player != null && client.player.getMainHandStack().getItem() instanceof SwordItem;
    }
}
