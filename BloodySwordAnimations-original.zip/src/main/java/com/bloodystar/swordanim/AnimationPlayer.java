package com.bloodystar.swordanim;

public final class AnimationPlayer {
    public enum Style {
        SWORD_FLIP("Sword Flip", 26),
        HEAVY_ATTACK("Heavy Attack", 32),
        SWORD_DANCE("Sword Dance", 48),
        PHANTOM_SLASH("Phantom Slash", 22),
        EXECUTION("Execution Style", 42);

        public final String title;
        public final int duration;
        Style(String title, int duration) { this.title = title; this.duration = duration; }
    }

    private Style selected = Style.SWORD_FLIP;
    private int tick;
    private boolean playing;

    public void select(Style style) { selected = style; }
    public Style selected() { return selected; }
    public boolean playing() { return playing; }
    public float progress() { return playing ? Math.min(1f, tick / (float) selected.duration) : 0f; }

    public void playSelected() {
        if (!playing) { tick = 0; playing = true; }
    }

    public void tick() {
        if (playing && ++tick >= selected.duration) playing = false;
    }

    // Normalized visual motion profile. Intended for the first-person item renderer hook.
    public float rotation() {
        if (!playing) return 0;
        float t = progress();
        return switch (selected) {
            case SWORD_FLIP -> (float)(Math.sin(t * Math.PI * 2) * 360);
            case HEAVY_ATTACK -> (float)(-105 * Math.sin(t * Math.PI));
            case SWORD_DANCE -> (float)(Math.sin(t * Math.PI * 4) * 360);
            case PHANTOM_SLASH -> (float)(-150 * Math.sin(t * Math.PI));
            case EXECUTION -> (float)(Math.sin(t * Math.PI * 2) * 180);
        };
    }
}
