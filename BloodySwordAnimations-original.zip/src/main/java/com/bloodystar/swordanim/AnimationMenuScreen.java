package com.bloodystar.swordanim;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class AnimationMenuScreen extends Screen {
    private static final AnimationPlayer.Style[] STYLES = AnimationPlayer.Style.values();

    public AnimationMenuScreen() { super(Text.literal("Bloody Sword Animations")); }

    @Override
    protected void init() {
        int w = 190, x = (width - w) / 2, y = height / 2 - 65;
        for (int i = 0; i < STYLES.length; i++) {
            final AnimationPlayer.Style style = STYLES[i];
            addDrawableChild(ButtonWidget.builder(
                    Text.literal((BloodySwordAnimations.PLAYER.selected() == style ? "» " : "") + style.title),
                    b -> { BloodySwordAnimations.PLAYER.select(style); ModConfig.get().selectedStyle = style.name(); ModConfig.save(); }
            ).dimensions(x, y + i * 25, w, 20).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + 132, w, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, "§5§lBLOODY SWORD ANIMATIONS", width / 2, height / 2 - 91, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Select a style • Left-click with a sword to play", width / 2, height / 2 + 100, 0xBBBBBB);
        super.render(context, mouseX, mouseY, delta);
    }
}
